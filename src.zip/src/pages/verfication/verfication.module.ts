import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VerficationPage } from './verfication';

@NgModule({
  declarations: [
    VerficationPage,
  ],
  imports: [
    IonicPageModule.forChild(VerficationPage),
  ],
})
export class VerficationPageModule {}
